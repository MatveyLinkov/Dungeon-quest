<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="castle_tileset" tilewidth="48" tileheight="48" tilecount="72" columns="9">
 <image source="castle_tileset.png" width="432" height="384"/>
</tileset>
